import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actorlist',
  templateUrl: './actorlist.component.html',
  styleUrls: ['./actorlist.component.css']
  
})
export class ActorlistComponent implements OnInit {

  actorList;  // In Angular we have atype called 'Any'
  listFlag: boolean;
  btnText: String;
  newName: String;
  newRating: number;
  selectedIndex:number;

  constructor() { }

  ngOnInit(): void {
    // all initialization part of component we can do in ngOnInit
    this.actorList=[
      {name:'Samuel',rating:'9'},  // JSON type values : key and values
      {name:'Emanuel',rating:'8.5'},
      {name:'Kay',rating:'9'},
      {name:'Mide',rating:'9.5'},
      {name:'Efe',rating:'8'},
      {name:'Mahendra',rating:'10'},
      {name:'Shabbir',rating:'1'}
    
    ];
    this.listFlag=true;
    this.btnText='Hide List';
    this.newName='',
    this.newRating=0;
    this.selectedIndex=-1;
  }

  toggleList(){
     this.listFlag=!this.listFlag; // from true to false !true = false
     this.btnText = this.listFlag ? 'Hide List' : 'Show List'; //terinary operator
  }

  deleteActor(index){
    this.actorList.splice(index, 1);
  }

  addActor(){
    this.actorList.push({
      name: this.newName,
      rating: this.newRating
    });
    this.newName=''
    this.newRating=0;
  }
  
  editActor(index){
    this.selectedIndex = index;
  }

  saveActor(index){
    this.selectedIndex = -1;
  }

  cancelEdit(index){
    this.selectedIndex = -1;
  }

}

