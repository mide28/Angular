import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';  // to work with Forms in Angular

import { AppComponent } from './app.component';
import { FirstComponent } from './sam/first/first.component';
import { ActorlistComponent } from './components/actorlist/actorlist.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    ActorlistComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
